function conCF = conCF(hf_proj, yf, lambda)

% get dimensions
[height, width, channel] = size(hf_proj);
conCF = zeros(height, width, channel);
for h = 1:height
    for w = 1:width
    x = reshape(hf_proj(h,w,:), [1,channel]);
    filter = (x'*x+lambda*eye(channel))^(-1)*x'*yf(h,w);
    conCF(h,w,:) = reshape(filter,[1,1,channel]);
    end
end

end