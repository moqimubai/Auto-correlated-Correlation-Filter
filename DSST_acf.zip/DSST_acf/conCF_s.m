function conCF_s = conCF_s(sf_proj, ysf, lambda)

% get dimensions
[channel, width] = size(sf_proj);
conCF_s = zeros(channel, width);
for w = 1:width
    x = reshape(sf_proj(:,w),[1,channel]);
    filter = (x'*x+lambda*eye(channel))^(-1)*x'*ysf(w);
    conCF_s(:, w) = reshape(filter,[channel,1]);
end

end